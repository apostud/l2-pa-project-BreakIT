#define Black 1
#define White 0

