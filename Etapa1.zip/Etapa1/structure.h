#include "constants.h"
enum PieceType { KING, QUEEN, BISHOP, KNIGHT, ROOK, PAWN, NONE };
// clasa pentru o piesa de pe tabla
class Piece {
private:
	int id;
	PieceType pieceType;
	bool captured;
	int color;
	int x;
	int y;
public:
	Piece();
	Piece(int id, PieceType pieceType, int color, int x, int y, bool captured);
	int getId();
	PieceType getPieceType();
	int getColor();
	int getX();
	int getY();
	bool isCaptured();
	void setId(int id);
	void setColor(int color);
	void setX(int x);
	void setY(int y);
	void setCaptured(bool status);
	void setPieceType(PieceType pieceType);
	void setNoPiece();
	Piece(const Piece &other);
	void changePieces(Piece *srcPiece);
};
// clasa pentru tabla de sah
class Board {
private:
	Piece square[9][9];
	Piece pieces[33];
	void updatePiecesArray(int id, int xFinal, int yFinal);
public:
	void setBoard();
	void setMove(char move[4], int turn);
	void makeMove(int turn);
};
