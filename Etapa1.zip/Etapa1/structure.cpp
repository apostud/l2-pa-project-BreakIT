#include <iostream>
#include <stdio.h>
#include <string.h>
#include "structure.h"
#include "constants.h"


Piece::Piece() {}
// constructor pentru o piesa de pe tabla
Piece::Piece(int id, PieceType pieceType, int color, int x,
int y, bool captured) {
    this->id = id;
    this->pieceType = pieceType;
    this->color = color;
    this->x = x;
    this->y = y;
    this->captured = captured;
}
int Piece::getId() {
    return id;
}
PieceType Piece::getPieceType() {
    return pieceType;
}
int Piece::getColor() {
    return color;
}
int Piece::getX() {
    return x;
}
int Piece::getY() {
    return y;
}
bool Piece::isCaptured() {
    return captured;
}
void Piece::setId(int id) {
    this->id = id;
}
void Piece::setColor(int color) {
    this->color = color;
}
void Piece::setX(int x) {
    this->x = x;
}
void Piece::setY(int y) {
    this->y = y;
}
void Piece::setCaptured(bool status) {
    this->captured = status;
}
void Piece::setPieceType(PieceType pieceType) {
    this->pieceType = pieceType;
}

void Piece::setNoPiece() {
    pieceType = NONE;
}
Piece::Piece(const Piece &other) {
    this->id = other.id;
    this->pieceType = other.pieceType;
    this->color = other.color;
    this->x = other.x;
    this->y = other.y;
    this->captured = other.captured;
}

void Piece::changePieces(Piece *srcPiece) {
    this->id = srcPiece->id;
    this->pieceType = srcPiece->pieceType;
    this->color = srcPiece->color;
    this->captured = srcPiece->captured;
}

void Board::setBoard() {
    // casutele goale
    for (int i = 3; i <= 6; i++) {
        for (int j = 1; j <= 8; j++) {
            square[i][j].setNoPiece();
        }
    }
    // pionii
    for (int i = 1; i <= 8; i++) {
        pieces[i] = Piece(i, PAWN, White, 2, i, false);
        square[2][i] = pieces[i];
        pieces[i + 8] = Piece(i + 8, PAWN, Black, 7, i, false);
        square[7][i] = pieces[i + 8];
    }

    // tura
    pieces[17] = Piece(17, ROOK, White, 1, 1, false);
    square[1][1] = pieces[17];
    pieces[19] = Piece(19, ROOK, Black, 8, 1, false);
    square[8][1] = pieces[19];
    pieces[18] = Piece(18, ROOK, White, 1, 8, false);
    square[1][8] = pieces[18];
    pieces[20] = Piece(20, ROOK, Black, 8, 8, false);
    square[8][8] = pieces[20];

    // calul
    pieces[21] = Piece(21, KNIGHT, White, 1, 2, false);
    square[1][2] = pieces[21];
    pieces[23] = Piece(23, KNIGHT, Black, 8, 2, false);
    square[8][2] = pieces[23];
    pieces[22] = Piece(22, KNIGHT, White, 1, 7, false);
    square[1][7] = pieces[22];
    pieces[24] = Piece(24, KNIGHT, Black, 8, 7, false);
    square[8][7] = pieces[24];

    // nebunul
    pieces[25] = Piece(25, BISHOP, White, 1, 3, false);
    square[1][3] = pieces[25];
    pieces[27] = Piece(27, BISHOP, Black, 8, 3, false);
    square[8][3] = pieces[27];
    pieces[26] = Piece(26, BISHOP, White, 1, 6, false);
    square[1][6] = pieces[26];
    pieces[28] = Piece(28, BISHOP, Black, 8, 6, false);
    square[8][6] = pieces[28];

    // regina
    pieces[29] = Piece(29, QUEEN, White, 1, 5, false);
    square[1][5] = pieces[29];
    pieces[30] = Piece(30, QUEEN, Black, 8, 4, false);
    square[8][4] = pieces[30];

    // regele
    pieces[31] = Piece(31, KING, White, 1, 4, false);
    square[1][4] = pieces[31];
    pieces[32] = Piece(32, KING, Black, 8, 5, false);
    square[8][5] = pieces[32];
}

void Board::updatePiecesArray(int id, int xFinal, int yFinal) {
    pieces[id].setX(xFinal);
    pieces[id].setY(yFinal);
}
void Board::setMove(char move[4], int turn) {
    int yInitial = (int)(move[0] - '0' - '0');
    int xInitial = (int)(move[1] - '0');
    int yFinal = (int)(move[2] - '0' - '0');
    int xFinal = (int)(move[3] - '0');
    int initialPieceId = square[xInitial][yInitial].getId();
    Piece finalPiece = square[xFinal][yFinal];
    if (turn == White) {
     // albul face mutarea
        if (finalPiece.getPieceType() == NONE) {
         // casuta destinatie este libera
            square[xFinal][yFinal].changePieces(&square[xInitial][yInitial]);
            square[xInitial][yInitial].setNoPiece();
            updatePiecesArray(initialPieceId, xFinal, yFinal);
        } else if (finalPiece.getColor() == Black) {
        // daca adversarul ne captureaza o piesa neagra
            int capturedPieceId = finalPiece.getId();
            square[xFinal][yFinal].changePieces(&square[xInitial][yInitial]);
            square[xInitial][yInitial].setNoPiece();
            updatePiecesArray(initialPieceId, xFinal, yFinal);
            // sterg piesa care se afla pe casuta destinatie
            // din vectorul de piese negre
            pieces[capturedPieceId].setCaptured(true);
        } else if (finalPiece.getColor() == White) {
        }
    } else {
    // negrul face mutarea
        if (finalPiece.getPieceType() == NONE) {
            // casuta destinatie este libera
            square[xFinal][yFinal].changePieces(&square[xInitial][yInitial]);
            square[xInitial][yInitial].setNoPiece();
            updatePiecesArray(initialPieceId, xFinal, yFinal);
        } else if (finalPiece.getColor() == White) {
            // daca adversarul ne captureaza o piesa alba
            int capturedPieceId = finalPiece.getId();
            square[xFinal][yFinal].changePieces(&square[xInitial][yInitial]);
            square[xInitial][yInitial].setNoPiece();
            updatePiecesArray(initialPieceId, xFinal, yFinal);
            // sterg piesa care se afla pe casuta
            // destinatie din vectorul de piese albe
            pieces[capturedPieceId].setCaptured(true);
        } else if (finalPiece.getColor() == Black) {
        }
    }
}

void Board::makeMove(int turn) {
    // actualizez mutarea in functie de pozitiile libere de pe tabla
    // si aleg cea mai convenabila mutare
    char move[20];
    char str[5];
    strcpy(move, "move ");
    if (turn == Black) {
        // aleg primul pion negru (cu id-ul 9)
        if (pieces[9].isCaptured() == false) {
            str[1] = ((char)pieces[9].getX() + '0');
            str[0] = (char)pieces[9].getY() + 2 * '0';
            int xFinal = pieces[9].getX() - 1;
            if (square[xFinal][pieces[9].getY()+1].getPieceType() != NONE) {
                str[3]=(char)(xFinal + '0');
                str[2]=(char)pieces[9].getY() +1 + 2 * '0';
                str[4] = '\0';
                strcat(move, str);
                setMove(str, turn);
                printf("%s\n", move);
                fflush(stdout);
            } else if (square[xFinal][pieces[9].getY()].getPieceType()
                == NONE) {
                str[3] = (char)(xFinal + '0');
                str[2] = (char)pieces[9].getY() + 2 * '0';
                str[4] = '\0';
                strcat(move, str);
                setMove(str, turn);
                printf("%s\n", move);
                fflush(stdout);
            } else {
                printf("resign\n");
                fflush(stdout);
            }
        } else {
            printf("resign\n");
            fflush(stdout);
        }
    } else {
        // aleg primul pion alb (cu id-ul 1)
        if (pieces[1].isCaptured() == false) {
            str[1] = ((char)pieces[1].getX() + '0');
            str[0] = (char)pieces[1].getY() + 2 * '0';
            int xFinal = pieces[1].getX() + 1;
            if (square[xFinal][pieces[1].getY()+1].getPieceType() != NONE) {
                str[3]=(char)(xFinal + '0');
                str[2]=(char)pieces[1].getY()+1 + 2 * '0';
                str[4] = '\0';
                strcat(move, str);
                setMove(str, turn);
                printf("%s\n", move);
                fflush(stdout);
            } else if (square[xFinal][pieces[1].getY()].getPieceType() == NONE){
                str[3] = (char)(xFinal + '0');
                str[2] = (char)pieces[1].getY() + 2 * '0';
                str[4] = '\0';
                strcat(move, str);
                setMove(str, turn);
                printf("%s\n", move);
                fflush(stdout);
            } else {
                printf("resign\n");
                fflush(stdout);
            }
        } else {
            printf("resign\n");
            fflush(stdout);
        }
    }
}
